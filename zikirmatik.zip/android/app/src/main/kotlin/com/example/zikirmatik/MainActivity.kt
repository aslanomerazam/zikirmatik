package com.example.zikirmatik

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
